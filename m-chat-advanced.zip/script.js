function switchAvatar(gender) {
  const avatar = document.getElementById("avatar");
  avatar.src = gender === "male" ? "images/male-avatar.jpg" : "images/female-avatar.jpg";
}

function speakText() {
  const text = document.getElementById("chat-output").innerText;
  const speech = new SpeechSynthesisUtterance(text);
  speech.lang = "mr-IN";
  window.speechSynthesis.speak(speech);
}